word = input(": ")
result = ""

for letter in word:
    result += letter*2

print(result)