x = float(input('Enter the first number: '))
y = float(input('Enter the second number: '))

operation = input("""Enter the the operation:
'+'
'-'
'*'
'/'
'^'
: """)

result = None
if operation == '+':
    result = x + y
elif operation == '-':
    result = x - y
elif operation == '*':
    result = x * y
elif operation == '/':
    result = x / y
elif operation == '^':
    result = x ** y
else:
    print('Unsupported operation')

if result is not None:
    print(result)