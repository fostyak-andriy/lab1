text = input(": ")
inputText = text.split(" ")
reversText = inputText[::-1]

reverse = ' '.join(reversText)
result = reverse[::-1]
print(result)
